#!/bin/bash

TMP_PING_FILE=/tmp/pingresult
TMP_TRACEROUTE_FILE=/tmp/tracerouteresult
PLANET_NAME_LIST_FILE=/network/rit/home/as267691/CN/p2/final_pair.txt
BASE_PATH=/network/rit/home/as267691/CN/p2/
keyfilename=amol_itsunix
username=albany_ccn1
PING_PACKET_COUNT=20

#
#	Pass file name as a parameter in which you want to append parsed ping data.
#
function parse_ping_data()
{
	#
	#	Gather required information from ping result
	#
	LOSS_PERCENTAGE=`grep transmitted $1 | awk -F"," '{print $3}' | awk -F" " '{print $1}' | sed 's/%//g'`
	TOTAL_TIME_REQUIRED=`grep transmitted $1 | awk -F" " '{print $NF}'`
	PACKETS_SENT=`grep transmitted $1 | awk -F" " '{print $1}'`
	PACKETS_RECEIVED=`grep transmitted $1 | awk -F"," '{print $2}' | awk -F" " '{print $1}'`

	#
	#	Dump information in the file
	#	Used pattern for the seperation of ping output and gathered information
	#
	echo "" >> $1
	echo "-------------- PING RESULT SUMMARY --------------" >> $1
	echo "Date: `date`" >> $1
	echo "Packets sent: $PACKETS_SENT" >> $1
	echo "Packets received: $PACKETS_RECEIVED" >> $1
	echo "Loss Percentage: $LOSS_PERCENTAGE" >> $1
	echo "Time Required: $TOTAL_TIME_REQUIRED" >> $1
}

#
#	Pass file name as a parameter in which you want to append parsed traceroute data.
#
function parse_traceroute_data()
{
	#
	#	Gather required information from traceroute result
	#
	#	Remove unwanted first line
	sed -i '1d' $1
	hop_count=0

	route=0
	str=`tail -n 1 $1 | grep -F "*  *  *"`
	if [ -z "$str" ];then
		route=1
	fi

	if [ $route -eq 1 ];then
		hop_count=`grep -Fv '*  *  *' $1 | wc -l | awk -F" " '{print $1}'`
	fi

	#
	#	Dump information in the file
	#	Used pattern for the seperation of traceroute output and gathered information
	#
	echo "" >> $1
	echo "-------------- TRACEROUTE RESULT SUMMARY --------------" >> $1
	echo "Date: `date`" >> $1
	echo "Found Route: $route" >> $1
	echo "Hop Count: $hop_count" >> $1
}

IFS=$'\n'
for line in `cat $PLANET_NAME_LIST_FILE`
do
	#
	#	Parse line to get node numbers and addresses.
	#
	first=`echo "$line" | awk -F" " '{print $1}'`
	second=`echo "$line" | awk -F" " '{print $2}'`
	firstname=`echo "$first" | awk -F":" '{print $1}'`
	firstaddr=`echo "$first" | awk -F":" '{print $2}'`
	secondname=`echo "$second" | awk -F":" '{print $1}'`
	secondaddr=`echo "$second" | awk -F":" '{print $2}'`

	echo "$firstname: $firstaddr, $secondname: $secondaddr"

	#
	#	Execute ping from first to second node.
	#
	node_to_node_ping_file="$BASE_PATH""$firstname""_""$secondname"".ping"
	cmd="ssh -i  $BASE_PATH$keyfilename  $username@$firstaddr ping -c $PING_PACKET_COUNT $secondaddr > $TMP_PING_FILE"
	eval $cmd
	if [ 0 -eq $? ];then
		parse_ping_data $TMP_PING_FILE

		#
		#	Append information in node to node ping file.
		#
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_ping_file
		cat $TMP_PING_FILE >> $node_to_node_ping_file
	else
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_ping_file
		echo "Node is down" >> $node_to_node_ping_file
		echo "Date: `date`" >> $node_to_node_ping_file
	fi

	#
	#	Execute ping from second to first node.
	#
	node_to_node_ping_file="$BASE_PATH""$secondname""_""$firstname"".ping"
	cmd="ssh -i $BASE_PATH$keyfilename   $username@$secondaddr ping -c $PING_PACKET_COUNT $firstaddr > $TMP_PING_FILE"
	eval $cmd
	if [ 0 -eq $? ];then
		parse_ping_data $TMP_PING_FILE

		#
		#	Append information in node to node ping file.
		#
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_ping_file
		cat $TMP_PING_FILE >> $node_to_node_ping_file
	else
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_ping_file
		echo "Node is down" >> $node_to_node_ping_file
		echo "Date: `date`" >> $node_to_node_ping_file
	fi

	#
	#	Execute traceroute from first to second node.
	#
	node_to_node_trace_file="$BASE_PATH""$firstname""_""$secondname"".trace"
	cmd="ssh -i $BASE_PATH$keyfilename  $username@$firstaddr traceroute $secondaddr > $TMP_TRACEROUTE_FILE"
	eval $cmd
	if [ 0 -eq $? ];then
		parse_traceroute_data $TMP_TRACEROUTE_FILE

		#
		#	Append information in node to node ping file.
		#
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_trace_file
		cat $TMP_TRACEROUTE_FILE >> $node_to_node_trace_file
	else
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_trace_file
		echo "Node is down" >> $node_to_node_trace_file
		echo "Date: `date`" >> $node_to_node_trace_file
	fi

	#
	#	Execute traceroute from second to first node.
	#
	node_to_node_trace_file="$BASE_PATH""$secondname""_""$firstname"".trace"
	cmd="ssh -i $BASE_PATH$keyfilename  $username@$secondaddr traceroute $firstaddr > $TMP_TRACEROUTE_FILE"
	eval $cmd
	if [ 0 -eq $? ];then
		parse_traceroute_data $TMP_TRACEROUTE_FILE

		#
		#	Append information in node to node ping file.
		#
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_trace_file
		cat $TMP_TRACEROUTE_FILE >> $node_to_node_trace_file
	else
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $node_to_node_trace_file
		echo "Node is down" >> $node_to_node_trace_file
		echo "Date: `date`" >> $node_to_node_trace_file
	fi

done

