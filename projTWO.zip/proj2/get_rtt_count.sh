#!/bin/bash

#
#	Below loop calculate rtt average and loss percentage.
#
for file in `ls *.ping`
do
	name=`echo $file | awk -F"." '{print $1}'`;
	grep "^rtt" $file | awk -F"=" '{print $2}' | awk -F"/" '{print $2}' > "$name.rttavg"
	grep "^Loss Percentage: " $file | awk -F": " '{print $2}' > "$name.lossper"
done