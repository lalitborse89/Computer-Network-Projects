import java.io.*;
import java.util.*;
import java.util.regex.Pattern;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class Test_Flcutuate {

 private static final Pattern PATTERN = Pattern.compile(
         "^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

  
public static void main(String[] args) throws IOException 
{
 // System.out.println("Hello Java");

  String delims2 = " ";
  String delims1 = " ";
  
  String [] FileArray= new String[14];
  
  for(int i = 0; i < 14; i+=2)
  {
  
    String filename = (new Integer(i+1)).toString()+"_"+(new Integer(i+2)).toString()+".trace";
    FileArray[i] = filename;
    
    //System.out.println("File name is "+ filename);
    
    filename = (new Integer(i+2)).toString()+"_"+(new Integer(i+1)).toString()+".trace";
    FileArray[i+1] = filename;
    
    //System.out.println("File name is "+ filename);
    
  }
  
  for(int iLoop = 0; iLoop < 1; iLoop++)
  {

    FileInputStream fstream = new FileInputStream(FileArray[iLoop]);
    BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
    
    String strLine;
    String FileURL = null;
    
    int[] arr= new int[31];
    
    for(int i=0; i<31; i++)
    {
      arr[i] = 0;
    }
    
    int totalhopcount = 0;
    int totalresultrows = 0;
    int totalrecord = 1;
    int iTotlFluterringCount = 0;
    String FirstToken;
    strLine = br.readLine();
    
    while ((strLine = br.readLine()) != null) 
    {
      //System.out.println("line is "+strLine);
      if(strLine.contains("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"))
      {
        
        //System.out.println(totalhopcount);
        for(int i=0; i < 31; i++)
        {
          arr[i] = 0;
        }
        
        totalrecord++;
        totalhopcount = 0;
        continue;
      }
      
      
      StringTokenizer st = new StringTokenizer(strLine, delims1);
      
      try
      {
        
        FirstToken = (String)st.nextElement();
        //System.out.println("First token is "+ FirstToken);
        Integer.parseInt(FirstToken); 
      }
      catch(Exception e)
      {
        //System.out.println(e);
        continue;
      }
      
      //System.out.println("Yes this is traceroute output"+ FirstToken+"current hop count value is "+totalhopcount);
      
      try
      {
        String RouterName = (String)st.nextElement();
        
        if(strLine.indexOf(RouterName) != strLine.lastIndexOf(RouterName))
        {
         // System.out.println("Fluterring Router name is" + RouterName);
          iTotlFluterringCount++;
        }
      }
      catch(Exception e)
      {
        System.out.println("Invalid input file"+ e);
      }
      
      totalhopcount++;
      
      totalresultrows++;
      
    }
    
  
  System.out.println("The total records are "+ totalrecord+" , Total rows are "+ totalresultrows +" Total Fluterring "+ iTotlFluterringCount+" % fluterring "+(float)iTotlFluterringCount/totalresultrows);
  }

}



}