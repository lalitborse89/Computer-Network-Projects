#!/bin/bash

#
#	Below loop calculate hop count.
#
for file in `ls *.trace`
do
	name=`echo $file | awk -F"." '{print $1}'`;
	grep "^Hop Count" $file | awk -F": " '{print $2}' > "$name.hopcnt"
done

