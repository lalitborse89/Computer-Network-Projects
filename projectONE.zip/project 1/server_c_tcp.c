/*Following links are reffered for this project.

For expression solving:
http://www.geeksforgeeks.org/expression-evaluation/

TCP:
https://www.youtube.com/watch?v=V6CohFrRNTo
http://www.thegeekstuff.com/2011/12/c-socket-programming/


UDP:
https://www.youtube.com/watch?v=Emuw71lozdA
https://vinodthebest.wordpress.com/category/c-programming/c-network-programming/
*/


//
//===================================================================
//	H E A D E R S.
//===================================================================

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>


//===================================================================
//	M A C R O S.
//===================================================================

#define QUEUESIZE					5
#define BUF_SIZE					256
#define PORT_NUMBER					8080


#define	RESULT_SUCCESS					0
#define	ERROR_INVALID_EXPRESSION			1001

#define	REQUEST_EVAL_EXPRESSION				2001



//===================================================================
//	S T R U C T U R E 
//===================================================================


struct CLIENT_REQUEST
{
	int iRequest;
	int iDataLength;
};

struct SERVER_RESPONSE
{
	int iResponseCode;
	int iResult;
};


//===================================================================
//	F U N C T I O N  P R O T O T Y P E S.
//===================================================================

int
EvalExpression(
	const char* pszExpression,
	int *piResult
	);

int
HandleClientRequest(
	int iClientSocket
	);

int
main(
	);




int iarrValues[BUF_SIZE + 1];
char charrOprator[BUF_SIZE + 1];
char charrExpression[BUF_SIZE + 1];

int hasPrecedence(char op1, char op2);
int applyOp(char op, int b, int a, int *);
int EvalExpression(const char* pszExpression, int *piResult);

int
EvalExpression(
    const char* pszExpression,
    int *piResult
    )
{
    int i;
    int ctr;
    int top=-1;
    int result;
    int success;
    int topOper=-1;
    int iTemp = 0;
    char charrTempBuff[10];
   
    int iwatch;
    char charwatch;
    char ch1;
    char ch2;
    int oprand1;
    int oprand2;
             
    for (i = 0; pszExpression[i]!='\0'; i++)
    {
         // Current token is a whitespace, skip it
        if (pszExpression[i] == ' ')
            continue;

        // Current token is a number, push it to stack for numbers
        if (pszExpression[i] >= '0' && pszExpression[i] <= '9')
        {
       
            //printf("\npszExpression[%d] is %c", i, pszExpression[i]);
           
            iwatch = i;
            charwatch = pszExpression[i];
   
            iTemp = 0;
           
            ch1 = pszExpression[i];
           
//            while (pszExpression[i] != '\0' && pszExpression[i] >= '0' && pszExpression[i] <= '9')
            while (pszExpression[i] != '\0' && (ch1 >= '0') && (ch1 <= '9'))
            {
                charrTempBuff[iTemp++] = pszExpression[i++];
               
                ch1 = pszExpression[i];
            //    ch2 =
               
               
            }
            //in for we are already doing ++
            i--;
            charrTempBuff[iTemp++] = '\0';
           
            sscanf(charrTempBuff, "%d", &iarrValues[++top]);
        //    printf("\n The number scanned is %d.", iarrValues[top]);
           
        }
        else if (pszExpression[i] == '(')
        {
            charrOprator[++topOper] =  pszExpression[i];
        }
        else if (pszExpression[i] == ')')
        {
            while (charrOprator[topOper] != '(')
            {
              oprand2 = iarrValues[top--];
              oprand1 = iarrValues[top--];
             

              success = applyOp(charrOprator[topOper], oprand2, oprand1, &result);
	      if(0 != success || top < -1)
		return -1;

              topOper--;
              iarrValues[++top] = result;
            }
	   
           topOper--;
        }
        else if (pszExpression[i] == '+' || pszExpression[i] == '-' ||
                 pszExpression[i] == '*' || pszExpression[i] == '/')
        {
            while ((topOper != -1) && (hasPrecedence(pszExpression[i], charrOprator[topOper])))
            {
               
                oprand2 = iarrValues[top--];
                oprand1 = iarrValues[top--];
                 
		success = applyOp(charrOprator[topOper], oprand2, oprand1, &result);
		if(0 != success || top < -1)
			return -1;

                topOper--;
                iarrValues[++top] = result;
            }

            charrOprator[++topOper] =  pszExpression[i];
        }

    }

    while (topOper != -1)
    {
       
        oprand2 = iarrValues[top--];
        oprand1 = iarrValues[top--];
 
	success = applyOp(charrOprator[topOper], oprand2, oprand1, &result);
	if(0 != success || top < -1)
		return -1;
        topOper--;
        iarrValues[++top] = result;
       
        //printf("\nResult is %d.", result);
    }

   *piResult =  iarrValues[0];
   //printf("\nThe result is %d", *piResult);
  

    if(topOper != -1)
	return -1;

   return 0;
}
 
 
int hasPrecedence(char op1, char op2)
{
    if (op2 == '(' || op2 == ')')
        return 0;
    if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
        return 0;
    else
        return 1;
}


int applyOp(char op, int b, int a, int *res)
{
    switch (op)
    {
    case '+':
	*res = a + b;
        return 0;
    case '-':
	*res = a - b;
        return 0;
    case '*':
	*res = a * b;
        return 0;
    case '/':
        if (b == 0)
		return -1;
	*res = a / b;
        return 0;
    }
   
    return 0;
}


int
HandleClientRequest(
	int iClientSocket
	)
{
	int iRet;
	int iResult;
	int iDataLength;
	struct CLIENT_REQUEST Request;
	struct SERVER_RESPONSE Response;
	char szBuffer[BUF_SIZE + 1];


	//
	//	Receive request type and data length.
	//
	iRet = recv(iClientSocket, &Request, sizeof(Request), 0);
	if (sizeof(Request) != iRet)
	{
		printf("\nrecv Failed while receiving Request.");
		printf("%s\n", strerror(errno));
		close (iClientSocket);
		return 0;
	}


	//
	//	Expression length should not exceed maximum length.
	//
	if (Request.iDataLength > BUF_SIZE)
	{
		//
		//	Notify client about invalid expression.
		//
		printf("\nInput Data Overloaded.");
		Response.iResponseCode = ERROR_INVALID_EXPRESSION;
		send(iClientSocket, &Response, sizeof(Response), 0);
		close(iClientSocket);
		return 0;
	}


	//
	//	Receive expression.
	//
	memset(szBuffer, 0, sizeof(szBuffer));
	iRet = recv(iClientSocket, szBuffer, Request.iDataLength, 0);
	if (iRet != Request.iDataLength)
	{
		//
		//	Notify client about invalid expression.
		//
		printf("\nIncomplete data transfer.");
		Response.iResponseCode = ERROR_INVALID_EXPRESSION;
		send(iClientSocket, &Response, sizeof(Response), 0);
		close(iClientSocket);
		return 0;
	}


	//
	//	Calculate result of expression.
	//
	iRet = EvalExpression(szBuffer, &iResult);
	if (-1 == iRet)
	{
		//
		//	Notify client about invalid expression.
		//
		//printf("\nExpression Evaluation failed.");
		printf("\nDid not receive valid expression from client.\n");
		Response.iResponseCode = ERROR_INVALID_EXPRESSION;
		send(iClientSocket, &Response, sizeof(Response), 0);
		close(iClientSocket);
		return -1;
	}


	Response.iResponseCode = RESULT_SUCCESS;
	Response.iResult = iResult;
	iRet = send(iClientSocket, &Response, sizeof(Response), 0);
	if (iRet != sizeof(Response))
	{
		printf("\n Send failed.");
		printf("%s\n", strerror(errno));
		close (iClientSocket);
		return 0;
	}


	//
	//	Get absolute value of result.
	//
	iResult *= (iResult < 0 ? -1 : 1);
	for (iRet = 0; iRet < iResult; iRet++)
	{
		send(iClientSocket, "Socket Programming\n", strlen("Socket Programming\n"), 0);
	}

	close(iClientSocket);
	return 0;
}


int main(int argc, char*argv[])
{
	int iRet;
	int iServerSocket;
	int iClientSocket;
	short int siPortNumber;
	struct sockaddr_in ServerAddr;		//	server address structure.

	if (argc != 2)
	{
		printf("Usage: %s <Port>", argv[0]);
		return -1;
	}

	siPortNumber = atoi(argv[1]);

	if(siPortNumber < 0 ||  siPortNumber > 65535)
	{
		printf("\nInvalid port number. Terminating.");
		
		return;
	}
	

	//printf("\nserver started");

	//
	//	Create server socket.
	//
	iServerSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (-1 == iServerSocket)
	{
		printf("%s\n", strerror(errno));
		printf("\nsocket Failed.");
		return -1;
	}

	

	memset(&ServerAddr, '\0', sizeof(ServerAddr));
	ServerAddr.sin_family = AF_INET;
	ServerAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	ServerAddr.sin_port = htons(siPortNumber);


	//
	//	Bind server with address.
	//
	iRet = bind(iServerSocket, (struct sockaddr*)&ServerAddr, sizeof(struct sockaddr_in));
	if (-1 == iRet)
	{
		printf("%s\n", strerror(errno));
		printf("\nbind Failed.");
		close(iServerSocket);
		return -1;
	}

	listen(iServerSocket, QUEUESIZE);

	//
	//	Server continuously accept connections.
	//
	while (1)
	{
		iClientSocket = accept(iServerSocket, NULL, NULL);
		if (-1 == iClientSocket)
		{
			if(errno  == EINTR)
			{
				continue;	
			}

			printf("Accept call failed for error %s\n", strerror(errno));
			continue;
		}

		//
		//	Handle client request.
		//
		iRet = HandleClientRequest(iClientSocket);
		//printf("\n iRet Value is %d", iRet);
		//if(iRet != 0)
			//break;
	}

	close(iServerSocket);
	return 0;
}

