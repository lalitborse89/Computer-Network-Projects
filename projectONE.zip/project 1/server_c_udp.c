/*Following links are reffered for this project.

For expression solving:
http://www.geeksforgeeks.org/expression-evaluation/

Timeout:
http://www.danzig.us/tcp-ip-lab/inet-dgram/timeout/

TCP:
https://www.youtube.com/watch?v=V6CohFrRNTo
http://www.thegeekstuff.com/2011/12/c-socket-programming/


UDP:
https://www.youtube.com/watch?v=Emuw71lozdA
https://vinodthebest.wordpress.com/category/c-programming/c-network-programming/
*/


//===================================================================
//	H E A D E R S.
//===================================================================

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>


//===================================================================
//	M A C R O S.
//===================================================================

#define BUF_SIZE					256


#define	RESULT_SUCCESS				0
#define	ERROR_INVALID_EXPRESSION	1001

#define	REQUEST_EVAL_EXPRESSION		2001

#define	RESPONSE_STRING				"Socket Programming\n"

struct SERVER_RESPONSE
{
	int iResponseCode;
	int iResult;
	int iDataLength;
};

//===================================================================
//	F U N C T I O N  D E F I N I T I O N S.
//===================================================================

int iarrValues[BUF_SIZE + 1];
char charrOprator[BUF_SIZE + 1];
char charrExpression[BUF_SIZE + 1];

int hasPrecedence(char op1, char op2);
int applyOp(char op, int b, int a, int *);
int EvalExpression(const char* pszExpression, int *piResult);

int
EvalExpression(
    const char* pszExpression,
    int *piResult
    )
{
    int i;
    int top=-1;
    int result;
    int success;
    int topOper=-1;
    int iTemp = 0;
    char charrTempBuff[10];
   
    char ch1;
    int oprand1;
    int oprand2;
 
    for (i = 0; pszExpression[i]!='\0'; i++)
    {
         // Current token is a whitespace, skip it
        if (pszExpression[i] == ' ')
            continue;

        // Current token is a number, push it to stack for numbers
        if (pszExpression[i] >= '0' && pszExpression[i] <= '9')
        {
       
            //printf("\npszExpression[%d] is %c", i, pszExpression[i]);
           
            iTemp = 0;
           
            ch1 = pszExpression[i];
           
//            while (pszExpression[i] != '\0' && pszExpression[i] >= '0' && pszExpression[i] <= '9')
            while (pszExpression[i] != '\0' && (ch1 >= '0') && (ch1 <= '9'))
            {
                charrTempBuff[iTemp++] = pszExpression[i++];
               
                ch1 = pszExpression[i];
            //    ch2 =
               
               
            }
            //in for we are already doing ++
            i--;
            charrTempBuff[iTemp++] = '\0';
           
            sscanf(charrTempBuff, "%d", &iarrValues[++top]);
        //    printf("\n The number scanned is %d.", iarrValues[top]);
           
        }
        else if (pszExpression[i] == '(')
        {
            charrOprator[++topOper] =  pszExpression[i];
        }
        else if (pszExpression[i] == ')')
        {
            while (charrOprator[topOper] != '(')
            {
              oprand2 = iarrValues[top--];
              oprand1 = iarrValues[top--];
             

              success = applyOp(charrOprator[topOper], oprand2, oprand1, &result);
	      if(0 != success || top < -1)
		return -1;

              topOper--;
              iarrValues[++top] = result;
            }

	  topOper--;
        }
        else if (pszExpression[i] == '+' || pszExpression[i] == '-' ||
                 pszExpression[i] == '*' || pszExpression[i] == '/')
        {
            while ((topOper != -1) && (hasPrecedence(pszExpression[i], charrOprator[topOper])))
            {
               
                oprand2 = iarrValues[top--];
                oprand1 = iarrValues[top--];
                 
		success = applyOp(charrOprator[topOper], oprand2, oprand1, &result);
		if(0 != success || top < -1)
			return -1;

                topOper--;
                iarrValues[++top] = result;
            }

            charrOprator[++topOper] =  pszExpression[i];
        }

    }

    while (topOper != -1)
    {
       
        oprand2 = iarrValues[top--];
        oprand1 = iarrValues[top--];
 
	success = applyOp(charrOprator[topOper], oprand2, oprand1, &result);
	if(0 != success || top < -1)
		return -1;
        topOper--;
        iarrValues[++top] = result;
       
        //printf("\nResult is %d.", result);
    }

   *piResult =  iarrValues[0];
   //printf("\nThe result is %d", *piResult);
  
    if(topOper != -1)
	return -1;

   return 0;
}
 
 
int hasPrecedence(char op1, char op2)
{
    if (op2 == '(' || op2 == ')')
        return 0;
    if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
        return 0;
    else
        return 1;
}


int applyOp(char op, int b, int a, int *res)
{
    switch (op)
    {
    case '+':
	*res = a + b;
        return 0;
    case '-':
	*res = a - b;
        return 0;
    case '*':
	*res = a * b;
        return 0;
    case '/':
        if (b == 0)
		return -1;
	*res = a / b;
        return 0;
    }
   
    return 0;
}

int readable_or_timeout (int sd, int timeout_in_seconds)
{
  int status;
  struct timeval tv;       
  fd_set  read_sd_set; 
  
  
  FD_ZERO (&read_sd_set);
  FD_SET  (sd, &read_sd_set);

  
  tv.tv_sec = timeout_in_seconds;
  tv.tv_usec = 0;  

  status = select(
		   sd+1,         /* highest-numbered descriptor + 1 */
		   &read_sd_set, /* descriptor set for reading */
		   NULL,         /* descriptor set for writing (none) */
		   NULL,         /* descriptor set for exceptions (none) */
		   &tv
		   );            /* time out */

  /* if there was an error or timed out, print a message. But do NOT exit. */
  if(status <  0)
  {
	perror ("select error");
  }
 
   return (status);
}


int
HandleClientRequest(
	int iSockfd,
	int iDataLength,
	struct sockaddr_in *ClientSocketAddr
	)
{
	int i;
	int iRet;
	int iResult;
	int result;
	int iAttempt;
	struct timeval tv;
	char szBuffer[BUF_SIZE + 1];
	struct SERVER_RESPONSE Response;

	memset(&szBuffer, '\0', sizeof(szBuffer));
	result = readable_or_timeout(iSockfd, 1);
    if (result < 0)
    {
	  printf("Error Occured.");
	  return -1;
    }
   
    if(0 == result)
    {
		//
		//	Timeout occurs. Print error message and return.
		//
		printf("\n\tDid not receive valid expression from client. Terminating.\n\n");
		
		return -1;
    }	

	//
	//	Receive expression.
	//
	iRet = recvfrom(iSockfd, szBuffer, iDataLength, 0, NULL, 0);
	if (-1 == iRet && (EAGAIN == errno || EWOULDBLOCK == errno))
	{
		//
		//	Timeout occurs. Print error message and return.
		//
		printf("\n\tDid not receive valid expression from client. Terminating.\n\n");
		return -1;
	}
	else if (iDataLength != iRet)
	{
		printf("\n\tDid not receive valid expression from client. Terminating.\n\n");
		return -1;
	}

	//
	//	Send acknowledgment to client.
	//
	iRet = sendto(iSockfd, "ACK", 3, 0, (struct sockaddr*)ClientSocketAddr, sizeof(*ClientSocketAddr));
	if (3 != iRet)
	{
		perror("sendto 1:");
		return -1;
	}

	//printf("szBuffer: %s\n\n", szBuffer);
	iRet = EvalExpression(szBuffer, &iResult);
	if (-1 == iRet)
	{
		//
		//	Notify client about invalid expression.
		//
		//printf("\nExpression Evaluation failed.\n");
		printf("Did not receive valid expression from client.. Terminating.\n");
		Response.iResponseCode = ERROR_INVALID_EXPRESSION;
		Response.iDataLength = 0;
		iRet = sendto(iSockfd, &Response, sizeof(Response), 0, (struct sockaddr*)ClientSocketAddr, sizeof(*ClientSocketAddr));
		return -1;
	}

	Response.iResponseCode = RESULT_SUCCESS;
	Response.iResult = iResult;

	//
	//	Get absolute value of result.
	//
	iResult *= (iResult < 0 ? -1 : 1);

	//
	//	Calculate data length.
	//
	Response.iDataLength = iResult * strlen(RESPONSE_STRING);

	//
	//	Send result.
	//
	iRet = sendto(iSockfd, &Response, sizeof(Response), 0, (struct sockaddr*)ClientSocketAddr, sizeof(*ClientSocketAddr));
	if (iRet != sizeof(Response))
	{
		perror("sendto failed:");
		printf("Result trandmission failed. Terminating.\n");
		return -1;
	}

	//
	//	Send data to client.
	//
	for (i = 0; i < iResult; i++)
	{
		iAttempt = 0;

		while (1)
		{
			iAttempt++;

			iRet = sendto(iSockfd, RESPONSE_STRING, strlen(RESPONSE_STRING), 0, (struct sockaddr*)ClientSocketAddr, sizeof(*ClientSocketAddr));
			if (iRet != strlen(RESPONSE_STRING))
			{
				perror("sendto failed:");
				printf("Result trandmission failed. Terminating.\n");
				return -1;
			}

			result = readable_or_timeout(iSockfd, 1);
			// Check status
			if (result < 0)
			{
			  printf("Result trandmission failed. Terminating.\n");
			  return -1;
			}

			if(0 == result)
			{
			 //
			 //	Terminate after 3 attempts.
			 //
			 if (iAttempt == 4)
			 {
				printf("\n\tFailed to send expression. Terminating.\n\n");
				close(iSockfd);
				return -1;
			 }
			 
				printf("*** Didn't received acknowledgement. Retrying....\n");
				continue;	
			}	
			
			//
			//	Receive acknowledgement.
			//
			iRet = recvfrom(iSockfd, szBuffer, 3, 0, NULL, 0);
			if (-1 == iRet && (EAGAIN == errno || EWOULDBLOCK == errno))
			{
				//
				//	Terminate after 3 attempts.
				//
				if (iAttempt == 4)
				{
					printf("Result trandmission failed. Terminating.\n");
					return -1;
				}

				printf("*** Didn't received acknowledgement. Retrying....\n");
				continue;
			}
			else if (3 != iRet)
			{
				perror("recvfrom:");
				return -1;
			}

			//
			//	Break loop if acknowledgement is received.
			//
			break;
		}

	}

	return 0;
}

int
main(
	int argc,
	char *argv[]
	)
{
	int iRet;
	int iSockfd;
	int iDataLength;
	int iServerPort;
	socklen_t iAddrlen;
	struct timeval tv;
	struct sockaddr_in ServerSocketAddr;
	struct sockaddr_in ClientSocketAddr;

	//
	//	Check validity of arguments.
	//
	if (argc != 2)
	{
		printf("Usage: %s <Port>", argv[0]);
		return -1;
	}

	//printf("\nserver started");

	iServerPort = atoi(argv[1]);

	if(iServerPort < 0 ||  iServerPort > 65535)
	{
		printf("\nInvalid port number. Terminating.");
		
		return;
	}
	
	//
	//	Create socket.
	//
	iSockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (-1 == iSockfd)
	{
		perror("socket:");
		return -1;
	}

	//
	//	Bind server to given IP and port.
	//
	ServerSocketAddr.sin_family = AF_INET;
	ServerSocketAddr.sin_port = htons(iServerPort);
	ServerSocketAddr.sin_addr.s_addr = htonl(INADDR_ANY);

	iRet = bind(iSockfd, (struct sockaddr*)&ServerSocketAddr, sizeof(ServerSocketAddr));
	if (-1 == iRet)
	{
		perror("bind:");
		close(iSockfd);
		return -1;
	}


	//
	//	Server will wait for request.
	//
	while (1)
	{
		iAddrlen = sizeof(ClientSocketAddr);
		iRet = recvfrom(iSockfd, &iDataLength, sizeof(iDataLength), 0, (struct sockaddr*)&ClientSocketAddr, &iAddrlen);
		if (sizeof(iDataLength) != iRet)
		{
			perror("recvfrom failed:");
			sleep(1);
			continue;
		}

		//printf("datalen: %d\n", iDataLength);
		iRet = HandleClientRequest(iSockfd, iDataLength, &ClientSocketAddr);
		if (0 != iRet)
		{
			//
			//	Terminate server on failure.
			//
			//printf("Handle client request failed\n");
			break;
		}
	}

	//sleep(1);
	return 0;
}

