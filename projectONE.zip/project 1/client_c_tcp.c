/*Following links are reffered for this project.

For expression solving:
http://www.geeksforgeeks.org/expression-evaluation/

TCP:
https://www.youtube.com/watch?v=V6CohFrRNTo
http://www.thegeekstuff.com/2011/12/c-socket-programming/


UDP:
https://www.youtube.com/watch?v=Emuw71lozdA
https://vinodthebest.wordpress.com/category/c-programming/c-network-programming/
*/


//
//===================================================================
//	H E A D E R S.
//===================================================================

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>


//===================================================================
//	M A C R O S.
//===================================================================

#define QUEUESIZE					5
#define BUF_SIZE					256
#define PORT_NUMBER					8080


#define	RESULT_SUCCESS					0
#define	ERROR_INVALID_EXPRESSION			1001

#define	REQUEST_EVAL_EXPRESSION				2001


//===================================================================
//	S T R U C T U R E 
//===================================================================

struct CLIENT_REQUEST
{
	int iRequest;
	int iDataLength;
};

struct SERVER_RESPONSE
{
	int iResponseCode;
	int iResult;
};


//===================================================================
//	F U N C T I O N  P R O T O T Y P E S.
//===================================================================


int
main(
    );


//===================================================================
//	F U N C T I O N  D E F I N I T I O N S.
//===================================================================

int main(int argc, char*argv[])
{
	int iRet;
	int iPortNumber;
	int iClientSocket;
	short int siPortNumber;
	char szBuffer[BUF_SIZE + 1];
	struct CLIENT_REQUEST Request;
	struct SERVER_RESPONSE Response;
	struct sockaddr_in ClientAddress;
	char charrServerAddress[BUF_SIZE+1];

 	printf("\nEnter server name or IP address: ");
	scanf("%s", charrServerAddress);

 	printf("\nEnter port: ");
	scanf("%hd",  &siPortNumber);

	//check for port number validatoin's.
	//0 to 65535
	if(siPortNumber < 0 ||  siPortNumber > 65535)
	{
		printf("\nInvalid port number. Terminating.");
		
		return;
	}
	
 	printf("\nEnter expression: ");
	scanf("%s", szBuffer);

	memset(&ClientAddress, '\0', sizeof(ClientAddress));
	memset(&Request, '\0', sizeof(Request));
	memset(&Response, '\0', sizeof(Response));

	//
	//	Create socket.
	//	SOCK_STREAM: TCP
	//
	iClientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (-1 == iClientSocket)
	{
		printf("\n Socket creation Failed.");
		//printf("%s\n", strerror(errno));
		return -1;
	}

	ClientAddress.sin_family = AF_INET;

	ClientAddress.sin_port = htons(siPortNumber);

	//
	// Check for localhost address or other.
	//
	if(0 == strcmp("localhost", charrServerAddress))
	{
		ClientAddress.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	}	
	else
	{
		ClientAddress.sin_addr.s_addr = inet_addr(charrServerAddress);	
	}


	//
	//	Connect to server.
	//
	iRet = connect(iClientSocket, (struct sockaddr*)&ClientAddress, sizeof(struct sockaddr_in));
	if (-1 == iRet)
	{
		printf("Could not connect to server. Terminating.\n");
		close(iClientSocket);
		return -1;
	}


	//
	// Send expression length to Server.
	//
	Request.iRequest = REQUEST_EVAL_EXPRESSION;
	Request.iDataLength = strlen(szBuffer);
	iRet = send(iClientSocket, &Request, sizeof(Request), 0);
	if (iRet != sizeof(Request))
	{
		printf("\n Failed to send expression. Terminating.");
		//printf("Failed to send Request. Terminating.");
		
		close (iClientSocket);
		return;
	}


	//
	// Send expression to Server.
	//
	iRet = send(iClientSocket, szBuffer, Request.iDataLength, 0);
	if (iRet != Request.iDataLength)
	{
		printf("\n Failed to send expression. Terminating.");
		printf("%s\n", strerror(errno));
		close (iClientSocket);
		return -1;
	}


	//
	// Receive result from Server.
	//
	iRet = recv(iClientSocket, &Response, sizeof(Response), 0);
	if (iRet != sizeof(Response))
	{
		printf("Could not fetch result. Terminating.\n");
		close (iClientSocket);
		return -1;
	}


	if (Response.iResponseCode != RESULT_SUCCESS)
	{
		printf("Server says invalid expression. Terminating.\n");
		close (iClientSocket);
		return -1;
	}


	//
	// Print the result.
	//
	//printf("Result of expression: %d\n", Response.iResult);
	printf("%d\n", Response.iResult);

	//
	// get the "Socket Programming" string from server.
	//
	while (1)
	{
		memset(szBuffer, '\0', sizeof(szBuffer));
		iRet = recv(iClientSocket, szBuffer, sizeof(szBuffer), 0);
		if (0 >= iRet)
		{
			break;
		}

		printf("%s", szBuffer);
	}

	close(iClientSocket);

	return 0;
}

