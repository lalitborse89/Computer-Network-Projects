/*Following links are reffered for this project.

For expression solving:
http://www.geeksforgeeks.org/expression-evaluation/

Timeout:
http://www.danzig.us/tcp-ip-lab/inet-dgram/timeout/

TCP:
https://www.youtube.com/watch?v=V6CohFrRNTo
http://www.thegeekstuff.com/2011/12/c-socket-programming/


UDP:
https://www.youtube.com/watch?v=Emuw71lozdA
https://vinodthebest.wordpress.com/category/c-programming/c-network-programming/
*/


//===================================================================
//	H E A D E R S.
//===================================================================

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>


//===================================================================
//	M A C R O S.
//===================================================================

#define BUF_SIZE					256


#define	RESULT_SUCCESS					0
#define	ERROR_INVALID_EXPRESSION			1001

#define	REQUEST_EVAL_EXPRESSION				2001

struct SERVER_RESPONSE
{
	int iResponseCode;
	int iResult;
	int iDataLength;
};


//===================================================================
//	F U N C T I O N  D E F I N I T I O N S.
//===================================================================



int readable_or_timeout (int sd, int timeout_in_seconds)
{
  int status;
  struct timeval tv;       
  fd_set  read_sd_set; 
  
  
  FD_ZERO (&read_sd_set);
  FD_SET  (sd, &read_sd_set);

  
  tv.tv_sec = timeout_in_seconds;
  tv.tv_usec = 0;  

  status = select(
		   sd+1,         /* highest-numbered descriptor + 1 */
		   &read_sd_set, /* descriptor set for reading */
		   NULL,         /* descriptor set for writing (none) */
		   NULL,         /* descriptor set for exceptions (none) */
		   &tv
		   );            /* time out */

  /* if there was an error or timed out, print a message. But do NOT exit. */
  if(status <  0)
  {
	perror ("select error");
  }
 
   return (status);
}


int
main(
	int argc,
	char *argv[]
	)
{
	int iRet;
	int iLength;
	int iSockfd;
	int iAttempt;
	short iServerPort;
	struct timeval tv;
	char szBuffer[BUF_SIZE + 1];
	struct SERVER_RESPONSE Response;
	char charrServerAddress[BUF_SIZE+1];
	struct sockaddr_in ServerSocketAddr;
	struct sockaddr_in ClientSocketAddr;

	printf("\nEnter server name or IP address: ");
	scanf("%s", charrServerAddress);

 	printf("\nEnter port: ");
	scanf("%hd",  &iServerPort);

	//check for port number validatoin's.
	//0 to 65535
	if(iServerPort < 0 ||  iServerPort > 65535)
	{
		printf("\nInvalid port number. Terminating.");
		
		return;
	}
	
 	printf("\nEnter expression: ");
	scanf("%s", szBuffer);

	iLength = strlen(szBuffer);

	//
	//	Create socket.
	//	SOCK_DGRAM: UDP
	//
	iSockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (-1 == iSockfd)
	{
		perror("socket:");
		return -1;
	}


	//
	//	Bind client to port & Address.
	//
	ClientSocketAddr.sin_family = AF_INET;
	ClientSocketAddr.sin_port = htons(3355);
	ClientSocketAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	iRet = bind(iSockfd, (struct sockaddr*)&ClientSocketAddr, sizeof(ClientSocketAddr));
	if (-1 == iRet)
	{
		perror("bind:");
		close(iSockfd);
		return -1;
	}


	//
	//	Set server IP address and port.
	//
	ServerSocketAddr.sin_family = AF_INET;
	ServerSocketAddr.sin_port = htons(iServerPort);

	//
	// Check for localhost address or other.
	//
	if(0 == strcmp("localhost", charrServerAddress))
	{
		ServerSocketAddr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	}	
	else
	{
		ServerSocketAddr.sin_addr.s_addr = inet_addr(charrServerAddress);	
	}


	iAttempt = 0;
	while (1)
	{
		iAttempt++;

		//
		//	Send expression length.
		//
		iRet = sendto(iSockfd, &iLength, sizeof(iLength), 0, (struct sockaddr*)&ServerSocketAddr, sizeof(ServerSocketAddr));
		if (sizeof(iLength) != iRet)
		{
			perror("sendto 1:");
			close(iSockfd);
			return -1;
		}


		//
		//	Send expression.
		//
		iRet = sendto(iSockfd, szBuffer, iLength, 0, (struct sockaddr*)&ServerSocketAddr, sizeof(ServerSocketAddr));
		if (iLength != iRet)
		{
			perror("sendto 2:");
			close(iSockfd);
			return -1;
		}

		//printf("\nBefore calling to readable_or_timeout");
		//result = select(iSockfd + 1, &readset, NULL, NULL, &tv);

		int result;
		result = readable_or_timeout(iSockfd, 1);
  	    if (result < 0)
	    {
		   printf("Error Occured.");
		   return -1;
	    }
	   
	   if(0 == result)
	   {
		 //
		 //	Terminate after 3 attempts.
		 //
		 if (iAttempt == 4)
		 {
			printf("\n\tFailed to send expression. Terminating.\n\n");
			close(iSockfd);
			return -1;
		 }
		 
			printf("*** Didn't received acknowledgement. Retrying....\n");
			continue;	
	   }	

		//
		//	Wait for acknowledgement.
		//
		iRet = recvfrom(iSockfd, szBuffer, 3, 0, NULL, 0);
		if (-1 == iRet && (EAGAIN == errno || EWOULDBLOCK == errno))
		{
			//
			//	Terminate after 3 attempts.
			//
			if (iAttempt == 4)
			{
				printf("\n\tFailed to send expression. Terminating.\n\n");
				close(iSockfd);
				return -1;
			}

			printf("*** Didn't received acknowledgement. Retrying....\n");
			continue;
		}
		else if (3 != iRet)
		{
			perror("recvfrom:");
			close(iSockfd);
			return -1;
		}

		//
		//	Break loop if acknowledgement is received.
		//
		//printf("Received acknowledgement\n");
		break;
	}

	//
	//	Receive result.
	//
	iRet = recvfrom(iSockfd, &Response, sizeof(Response), 0, NULL, 0);
	if (iRet != sizeof(Response))
	{
		//printf("iRet %d and sizeof(response) %d\n", iRet, sizeof(Response));
		
		printf("Could not fetch result from Server.\n");
		close(iSockfd);
		return -1;
	}


	if (RESULT_SUCCESS != Response.iResponseCode)
	{
		printf("Server says invalid expression. Terminating.\n");
		close(iSockfd);
		return -1;
	}

	//
	// Print the result.
	//
	//printf("Result of expression: %d\n", Response.iResult);
	printf("%d\n", Response.iResult);

	//
	//	Receive data.
	//
	iLength = 0;
	while (iLength != Response.iDataLength)
	{
		memset(szBuffer, 0, sizeof(szBuffer));
		iRet = recvfrom(iSockfd, szBuffer, BUF_SIZE, 0, NULL, 0);
		if (-1 == iRet)
		{
			perror("recvfrom failed:");
			close(iSockfd);
			return -1;
		}

		iLength += strlen(szBuffer);
		printf("%s", szBuffer);

		//
		//	Send acknowledgement.
		//
		iRet = sendto(iSockfd, "ACK", 3, 0, (struct sockaddr*)&ServerSocketAddr, sizeof(ServerSocketAddr));
		if (3 != iRet)
		{
			perror("sendto failed:");
			close(iSockfd);
			return -1;
		}
	}

	return 0;
}

